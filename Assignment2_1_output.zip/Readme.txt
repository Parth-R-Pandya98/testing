Git URL: https://github.com/Parth-R-Pandya98/CS700Assignment2code.git

# CS700Assignment2code

Section 1
In section 1, the program will create 10 diffrent arrays of random number with size of 100000, 1000000, and 10000000 each.


C++ was used to create this code.

This program will produce 10 unique random number arrays, each with a size of 100000, 1000000, and 10000000.

Thus, there will be a total of 30 arrays.

Execution:
first random array is filled with given size 100000, 1000000, and 10000000 each size array 10 different random arrays 
are generated first execution time for random to sorted array time taken, then sorted array to sorted array
execution time , sorted to reverse array execution time is displayed for each size arrays.

Output 

Size :1000000                    Time in second(s)

Arr/Exe. time       |    Arr 1     Arr 2     Arr 3     Arr 4     Arr 5     Arr 6     Arr 7     Arr 8     Arr 9     Arr 10    

Random exe. time    |    0.123     0.125     0.125     0.126     0.114     0.126     0.106     0.125     0.124     0.111     
Sorted exe. time    |    0.053     0.047     0.047     0.047     0.047     0.047     0.061     0.05      0.051     0.049     
Inverse exe. time   |    0.051     0.055     0.047     0.058     0.047     0.054     0.057     0.052     0.052     0.067     


*****************************************************************************************************************

output will be same for remaning size as well

Section 2
A file which will goint to be tested namely, 'sin_cos.h' is already given.

Execution:

This program contains unit test cases of sin and cos function test

These functions compute the sine and cosine of an angle
expressed in degrees. The result will be
an integer representing the sine or cosine as
ten-thousandths. For example, a result of 7071 represents
7071e-4 or 0.7071.


output: 
sin() function test case
Real value: 8666,  Verify value: 8660,  Degree: 120
THIS Test is :1 Fail

Real value: 6428,  Verify value: 6428,  Degree: 140
THIS Test is :2 Pass

Real value: 9848,  Verify value: 9849,  Degree: 80
THIS Test is :3 Fail

Test cases for cos() function
Real value: 9396,  Verify value: 9396,  Degree: 20
THIS Test is :1 Fail

Real value: 3420,  Verify value: 3420,  Degree: 70
THIS Test is :2 Fail

Real value: 1736,  Verify value: 1736,  Degree: 80
THIS Test is :3 Pass